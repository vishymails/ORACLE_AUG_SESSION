ansible-vault create secret.yml

ansible-vault create --vault-password-file=redhat secret.yml


ansible-vault edit secret1.yml

ansible-vault rekey secret1.yml

ansible-vault encrypt secret.yml secret2.yml


ansible-vault view secret.yml

ansible-vault decrypt secret.yml --output=secret_decryp.yml


ansible-playbook --ask-vault-pass secret.yml

tree


ansible-playbook --syntax-check --ask-vault-pass secret.yml
