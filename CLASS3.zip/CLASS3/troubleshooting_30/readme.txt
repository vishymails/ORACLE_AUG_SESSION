ansible-playbook playbook1.yml --step


ansible-playbook playbook1.yml --start-at-task="Show hostname"

ansible-playbook playbook1.yml --syntax-check

ansible-playbook playbook1.yml --log-path 


ansible-playbook -v playbook1.yml


-v
-vv
-vvv
-vvvv